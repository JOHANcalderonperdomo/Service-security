package com.sena.servicesecurity.IRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.DTO.IPersonDto;
import com.sena.servicesecurity.Entity.Customer;

@Repository
public interface ICustomerRepository extends IBaseRepository<Customer, Long>{

	 @Query(value = "SELECT\r\n"
				+ "\r\n"
				+ "    \r\n"
				+ "    `person`.`document`,\r\n"
				+ "   \r\n"
				+ "    `person`.`type_document`\r\n"
				+ "   \r\n"
				+ "FROM `service_security`.`person`\r\n"
				+ "where id = :id" , nativeQuery = true)
		
	 IPersonDto getDocument(@Param("id") Long id);
	  
}
