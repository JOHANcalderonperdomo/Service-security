package com.sena.servicesecurity.Service;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.sena.servicesecurity.DTO.IPersonDto;
import com.sena.servicesecurity.Entity.Customer;
import com.sena.servicesecurity.Entity.Person;
import com.sena.servicesecurity.IRepository.IBaseRepository;
import com.sena.servicesecurity.IRepository.ICustomerRepository;
import com.sena.servicesecurity.IService.ICustomerService;
import com.sena.servicesecurity.IService.IPersonService;


@Service
public class CustomerService extends ABaseService<Customer> implements ICustomerService {

	public ICustomerRepository repository;
	
	@Lazy
   private	IPersonService personService;
	
	public  CustomerService(ICustomerRepository repository, @Lazy IPersonService personService) {
		this.repository = repository;
		this.personService = personService;
	}
	
	@Override
	protected IBaseRepository<Customer, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}

	@Override
	public Customer savePersonCustomer(Person entity) throws Exception {
	    // Cambiar la dirección en el objeto recibido
		System.out.println(entity.getAddress()  + " - 0");
        Person person = personService.save(entity);
        
        System.out.println(person.getAddress()  + " ADRE++");

	    // Crear una nueva entidad Customer
	    Customer entityCustomer = new Customer();

	    // Generar el código del cliente usando la información de la persona
	    String codeCustomer = GenerateCodeCustomer(person.getDocumentType(), person.getDocument(), person.getCreatedAt());

	    // Configurar los atributos de la entidad Customer
	    entityCustomer.setCode(codeCustomer);
	    entityCustomer.setPerson(person);
	    entityCustomer.setState(true);
	    entityCustomer.setCreatedAt(LocalDateTime.now());
	    entityCustomer.setCreatedBy((long) 1);

	    // Guardar la entidad Customer y devolverla
	    Customer customer = repository.save(entityCustomer);
	    return customer;
	}

	@Override
	public Customer saves(Customer entity) throws Exception {
		try {
			System.out.println("hola - 1");
			IPersonDto person = repository.getDocument(entity.getPerson().getId());
			String type= person.getType_document();
			String document = person.getDocument();
			//obtener el año actual
			int currentYear = LocalDate.now().getYear();
			//combinar los ultimos 4 digitos de document
			String documentSuffix=document.substring(Math.max(0, document.length()-4));
			String code = currentYear +"-" + type +"-"+ documentSuffix;
			entity.setCode(code);
			entity.setCreatedAt(LocalDateTime.now());
			entity.setCreatedBy((long) 1); // Cuanto esté el loggin, se debe enviar el ID del usuario con Auth
			return getRepository().save(entity);
		} catch (Exception e) {
			// Captura la excepción
			throw new Exception("Error al guardar la entidad: " + e.getMessage());
		}
	}

	@Override
	public String GenerateCodeCustomer(String typeDocument, String document, LocalDateTime date)
			throws Exception {
		String documentDigit = document.substring(Math.max(0, document.length() - 4));
		String code = date.getYear() + "-" + typeDocument + "-" + documentDigit;
		return code;
	}

	@Override
	public void update(Long id, Customer entity) throws Exception {
		Optional<Customer> opCustomer = getRepository().findById(id);

		if (opCustomer.isEmpty()) {
			throw new Exception("Registro no encontrado");
		} else if (opCustomer.get().getDeletedAt() != null) {
			throw new Exception("Registro inhabilitado");
		}
 
		
		Person personUdate = entity.getPerson();
		Customer existingClient = opCustomer.get();
		Person PersonExist = existingClient.getPerson();
		
		
		// Verificar si el documento ha cambiado
		if (PersonExist.getDocument() !=entity.getPerson().getDocument() || PersonExist.getDocumentType() != entity.getPerson().getDocumentType()) {
			// El documento ha cambiado, genera un nuevo código
			Person person = entity.getPerson();
			String newCode = GenerateCodeCustomer(person.getDocumentType(), person.getDocument(),entity.getCreatedAt());
			existingClient.setCode(newCode);
		}

		// Copiar propiedades desde la entidad de entrada a la existente, ignorando
		// campos no actualizables
		personService.update(personUdate.getId(), personUdate);
		String[] ignoreProperties = { "id", "createdAt", "deletedAt", "createdBy", "deletedBy" };
		BeanUtils.copyProperties(entity, existingClient, ignoreProperties);

		// Actualizar las propiedades adicionales

		existingClient.setUpdatedAt(LocalDateTime.now());
		existingClient.setUpdatedBy((long) 1); // Cuando esté el logging, se debe enviar el ID del usuario con Auth

		// Guardar la entidad actualizada
		getRepository().save(existingClient);
	}
	


	

}
