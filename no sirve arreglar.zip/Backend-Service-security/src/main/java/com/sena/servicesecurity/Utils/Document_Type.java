package com.sena.servicesecurity.Utils;

public enum Document_Type {

	cedula,
	tarjeta_identidad,
	pasaporte,
	registroCivil
	
	
}
