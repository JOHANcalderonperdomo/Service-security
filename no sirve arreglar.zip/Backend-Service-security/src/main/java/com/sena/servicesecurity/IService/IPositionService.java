package com.sena.servicesecurity.IService;

import java.util.List;

import com.sena.servicesecurity.DTO.IPositionDto;
import com.sena.servicesecurity.Entity.Position;

public interface IPositionService extends IBaseService<Position> {
	
	List<IPositionDto> getListPositions();

}
