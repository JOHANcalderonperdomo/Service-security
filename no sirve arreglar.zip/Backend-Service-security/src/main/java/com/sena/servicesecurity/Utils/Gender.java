package com.sena.servicesecurity.Utils;

public enum Gender {

	masculino,
	femenino,
	otros
}
