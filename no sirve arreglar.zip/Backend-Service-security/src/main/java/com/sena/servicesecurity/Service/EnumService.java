package com.sena.servicesecurity.Service;

import org.springframework.stereotype.Service;

import com.sena.servicesecurity.IService.IEnumService;
import com.sena.servicesecurity.Utils.Document_Type;
import com.sena.servicesecurity.Utils.Gender;
import com.sena.servicesecurity.Utils.addresses;
import com.sena.servicesecurity.Utils.weekdays;
@Service
public class EnumService implements IEnumService{

	@Override
    public Document_Type[] getDocument_Type() {
        return Document_Type.values();
    }

	@Override
	public weekdays[] getWeekdays() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public addresses[] getAddresses() {
		return addresses.values();
	}

	@Override
	public Gender[] getGender() {
		// TODO Auto-generated method stub
		return Gender.values();
	}

	
}
