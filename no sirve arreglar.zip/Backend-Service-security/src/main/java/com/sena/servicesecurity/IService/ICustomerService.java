package com.sena.servicesecurity.IService;

import java.time.LocalDateTime;

import com.sena.servicesecurity.Entity.Customer;
import com.sena.servicesecurity.Entity.Person;

public interface ICustomerService extends IBaseService<Customer>{

	public String GenerateCodeCustomer(String typeDocument, String document, LocalDateTime createAt) throws Exception ;
	
	public void update(Long id, Customer entity) throws Exception;

	public Customer savePersonCustomer(Person entity) throws Exception;
	
	public Customer saves(Customer entity) throws Exception;

	
}
