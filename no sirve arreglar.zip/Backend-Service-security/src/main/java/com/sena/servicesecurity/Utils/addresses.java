package com.sena.servicesecurity.Utils;

public enum addresses {

	calle,
	abenida,
	carrera,
	bis
}
