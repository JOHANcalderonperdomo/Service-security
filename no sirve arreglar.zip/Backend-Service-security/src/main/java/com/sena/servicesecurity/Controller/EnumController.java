package com.sena.servicesecurity.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.servicesecurity.IService.IEnumService;
import com.sena.servicesecurity.Utils.Document_Type;
import com.sena.servicesecurity.Utils.Gender;
import com.sena.servicesecurity.Utils.addresses;
import com.sena.servicesecurity.Utils.weekdays;

import org.springframework.web.bind.annotation.GetMapping;








@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/enum")
public class EnumController {

	
	@Autowired
	private IEnumService service;
	
	@GetMapping("/tipodocumento")
	public Document_Type[] documento() {
		return service.getDocument_Type();
	}

	
	
	@GetMapping("/weekdays")
	public weekdays[] weekdays() {
		return service.getWeekdays();
	}
	

	@GetMapping("/addresses")
	public addresses[] addresses() {
		return service.getAddresses();
	}
	
	@GetMapping("/gender")
	public Gender[] gender() {
		return service.getGender();
	}
	
}
