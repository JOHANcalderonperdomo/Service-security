 package com.sena.servicesecurity.DTO;

public interface ICustomerDto extends IGenericDto{

}
