package com.sena.servicesecurity.DTO;



public interface IEmployedDto extends IGenericDto {
	
	String getSalary();

}
