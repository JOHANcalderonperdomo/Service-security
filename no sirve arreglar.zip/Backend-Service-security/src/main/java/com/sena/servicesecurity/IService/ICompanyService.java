package com.sena.servicesecurity.IService;

import java.util.List;

import com.sena.servicesecurity.DTO.ICompanyDto;
import com.sena.servicesecurity.Entity.Company;

public interface ICompanyService extends IBaseService<Company> {
	
	List<ICompanyDto> getList();

}
